const server = require('http').createServer();
const io = require('socket.io')(server,{
    cors:{
        origin: '*',
    }
});



const PORT = 8000;
let ClientCount = 0;

server.listen(PORT, () => {
    console.log("Server Started");
});

io.on('connection', (socket) => {
    console.log(`Player Connected wit id: ${socket.id}`);
    socket.on('ready', () => {
        ClientCount++;
        if(ClientCount % 2==0){
            io.emit('startGame', socket.id);
        }
    });

    socket.on('paddleMove', (data) => {
        socket.broadcast.emit('paddleMove', data);
    });

    socket.on('ballMove', (data) => {
        socket.broadcast.emit('ballMove', data);
    });
    
});